﻿#pragma once

#include "ApiEnum.h"
#include "IMarket.h"
#include "ITrade.h"
